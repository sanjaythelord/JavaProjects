package com.neo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.neo.dto.EmployeeDto;
import com.neo.entity.EmployeeSpring;
import com.neo.service.EmployeeService;

@RestController
public class MyRestController {

	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/students")
	public List<EmployeeDto> getAllStudents(){
    List<EmployeeDto> list=new ArrayList<>();
    list.add(new EmployeeDto(11,"sanjay","shah",100000.0,12,"sanjay@76gmail.com"));
    list.add(new EmployeeDto(12,"jay","shah",1000.0,15,"jay@7634gmail.com"));
    list.add(new EmployeeDto(11,"sanju","sharma",890000.0,17,"sanju@889gmail.com"));
    
    //this code will directly save in database table
    EmployeeSpring es=new EmployeeSpring();
    es.setFirstName("Darth");
    es.setLastName("Vedar");
    es.setSalary(100000000.0);
    es.setAge(100);
    es.setEmail("vedar360@gmail.com");
    
    employeeService.addEmployee(es);
    System.out.println("Data Added...");   
    
    return list;
	}
	
	
	
	
}
