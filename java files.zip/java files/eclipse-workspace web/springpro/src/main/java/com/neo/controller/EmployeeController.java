package com.neo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.neo.entity.EmployeeSpring;
import com.neo.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	//empPage is just a value that shows the url when listemployee is hovered in application.
	@RequestMapping(value="/empPage", method=RequestMethod.GET)
	public String getEmpPage() {
		return "addEmp";
	}
	
	@RequestMapping(value="/saveEmp",method=RequestMethod.POST)
	public String saveEmp(@ModelAttribute("employee") EmployeeSpring es,Model model,RedirectAttributes redirectAttributes) {
		
		employeeService.addEmployee(es);
		return "menu";
	}
	@RequestMapping(value="/listEmps",method=RequestMethod.GET)
	public String getEmployees(Model model) {
		List<EmployeeSpring> es= new ArrayList<EmployeeSpring>();
		es = employeeService.getAllEmployees();
		model.addAttribute("employeeList", es);
		System.out.println("List..."+es.size());
		return "listEmp";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable Integer id,Model model,RedirectAttributes redirectAttributes) {
		employeeService.deleteEmployee(id);
		redirectAttributes.addFlashAttribute("msg", "Data deleted successfully with id :: "+id);
		return "redirect:/listEmps";
	}
	
@GetMapping("/edit/{id}")
public String getEmp(@PathVariable Integer id,Model model) {
	System.out.println("edit id..."+id);
	EmployeeSpring es=employeeService.getEmployee(id);
	model.addAttribute("empDetail", es);
	return "editEmp";
}

@RequestMapping(value="/updateEmp",method=RequestMethod.POST)
public String updatesEmp(@ModelAttribute("employee")EmployeeSpring es,RedirectAttributes redirectAttributes) {
	employeeService.updateEmployee(es);
	redirectAttributes.addFlashAttribute("msg", "Data updated successfully");
	return "redirect:/listEmps";
	
}
}
