package com.neo.dao;

import java.util.List;

import com.neo.entity.EmployeeSpring;

public interface EmployeeDAO {
	
	public void addEmployee(EmployeeSpring employee);
	public List<EmployeeSpring> getAllEmployees();
	public void deleteEmployee( Integer employeeId);
	public EmployeeSpring getEmployee(Integer employeeId);
	public EmployeeSpring updateEmployee(EmployeeSpring employee);
	
}
