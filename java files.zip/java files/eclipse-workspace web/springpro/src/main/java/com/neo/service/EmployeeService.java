package com.neo.service;

import java.util.List;

import com.neo.entity.EmployeeSpring;

public interface EmployeeService {

	public void addEmployee(EmployeeSpring employee);
	
	public List<EmployeeSpring> getAllEmployees();
	
	public void deleteEmployee(Integer employeeId);
	
	public EmployeeSpring getEmployee(Integer employeeId);
	
	public  EmployeeSpring updateEmployee(EmployeeSpring employee);
}
