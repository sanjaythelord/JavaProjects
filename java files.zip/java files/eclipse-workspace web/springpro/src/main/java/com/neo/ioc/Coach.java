package com.neo.ioc;

public interface Coach {
	
	public String getDailyWorkOut();
	public String getDailyFortune();

}
