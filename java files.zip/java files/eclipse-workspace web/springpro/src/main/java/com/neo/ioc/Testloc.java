package com.neo.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Testloc {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/neo/ioc/applicationContext.xml");
		
		
		Coach co= context.getBean("myCoach", Coach.class);
		System.out.println("Mycoach..."+ co.getDailyWorkOut());
		System.out.println("Myfortune..."+ co.getDailyFortune());
		
	}
}
