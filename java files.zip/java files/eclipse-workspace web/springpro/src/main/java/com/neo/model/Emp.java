package com.neo.model;

import org.springframework.stereotype.Component;

@Component
public class Emp {

	public String firstName;
	public String lastName;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void displayFullName() {
		System.out.println("Firstname..."+firstName +"...Lastname..."+lastName);
	}
}
