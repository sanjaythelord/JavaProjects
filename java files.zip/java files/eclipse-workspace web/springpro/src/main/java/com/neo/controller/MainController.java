package com.neo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {

	@RequestMapping(value="/menu", method=RequestMethod.GET)
	public String goMenu(Model model) {
		System.out.println("Going Menu page");
		return "menu";
	}
}
