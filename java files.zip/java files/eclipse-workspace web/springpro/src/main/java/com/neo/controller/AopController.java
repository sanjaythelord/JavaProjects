package com.neo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.neo.model.Emp;

@Controller
public class AopController {

	@Autowired
	private Emp emp;
	
	@RequestMapping(value="/logs", method = RequestMethod.GET)
	public String getLogs() {
		Emp e=new Emp();
		e.setFirstName("Sanjay");
		e.setLastName("Shah");
		System.out.println(e.getFirstName());
		e.displayFullName();
		return "redirect:/menu";
	}
}
