package com.neo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.neo.dao.EmployeeDAO;
import com.neo.entity.EmployeeSpring;

@Repository
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDao;
	@Override
	@Transactional//for ACID properties
	public void addEmployee(EmployeeSpring employee) {
		
		employeeDao.addEmployee(employee);
		
	}

	@Override
	public List<EmployeeSpring> getAllEmployees() {
		List<EmployeeSpring> list= employeeDao.getAllEmployees();
		return list;
	}

	@Override
	@Transactional
	public void deleteEmployee(Integer employeeId) {
	employeeDao.deleteEmployee(employeeId);
		
	}

	@Override
	@Transactional
	public EmployeeSpring getEmployee(Integer employeeId) {
		EmployeeSpring es= employeeDao.getEmployee(employeeId);
		return es;
	}

	@Override
	@Transactional
	public EmployeeSpring updateEmployee(EmployeeSpring employee) {
		EmployeeSpring emp=employeeDao.updateEmployee(employee);
		return employee;
		//return emp;
	}

	
}
