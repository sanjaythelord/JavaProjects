package com.neo.ioc;

public interface FortuneService {

	public String getFortune();
}
