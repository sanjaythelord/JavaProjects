package com.neo.ioc;

public class BaseballCoach implements Coach{

	private FortuneService fortuneService;
	
	
	public BaseballCoach(FortuneService fortuneService) {
		this.fortuneService=fortuneService;
	}
	
	@Override
	public String getDailyWorkOut() {
		return "Run a hard 5K";
	}
	
	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}
	
}
