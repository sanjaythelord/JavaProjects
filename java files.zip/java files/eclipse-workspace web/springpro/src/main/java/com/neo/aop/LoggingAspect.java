package com.neo.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;

@Aspect // declare the class as aspect
@Configuration
public class LoggingAspect {

	@Before("execution(* com.neo.model.Emp.displayFullName(..))")
	public void specificMethod(JoinPoint joinPoint) {
		System.out.println("using logBefore() for displayFullName()!..."+joinPoint.getSignature().getName());
	}
	
	@After("execution(* com.neo.model.Emp.displayFullName(..))")
	public void usingAfterMethodForDisplayFullName() {
		System.out.println("Using After method...");
	}
	
	@Around("execution(* com.neo.model.Emp.displayFullName(..))")
	public void logAroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable{
		System.out.println("Around Before is running!");
		joinPoint.proceed();
		System.out.println("Around After is running!");
	}
	
	@AfterReturning(pointcut="execution(* com.neo.model.Emp.displayFullName(..))", returning="result")
	public void myadvice(JoinPoint jp, Object result) {
		System.out.println("After returning advice.......");
		System.out.println("Method Signature: " +jp.getSignature());
		System.out.println("Result in advice: "+ result);
		System.out.println("End of after returning advice....");
	}
}
