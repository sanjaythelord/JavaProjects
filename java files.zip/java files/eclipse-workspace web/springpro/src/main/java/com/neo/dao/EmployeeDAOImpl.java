package com.neo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.neo.entity.EmployeeSpring;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void addEmployee(EmployeeSpring employee) {
		sessionFactory.getCurrentSession().saveOrUpdate(employee);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<EmployeeSpring> getAllEmployees() {
		Session session=this.sessionFactory.getCurrentSession();
		
		List<EmployeeSpring> list=session.createQuery("from EmployeeSpring").list();
		System.out.println("listsize..."+list.size());
		return list;
	}

	@Override
	public void deleteEmployee(Integer employeeId) {
		Session session =this.sessionFactory.getCurrentSession();
	    EmployeeSpring es=session.load(EmployeeSpring.class, employeeId);
	    if(es!=null) {
	    	session.delete(es);
	    }
		System.out.println("Data deleted successfully.");
	}

	@Override
	public EmployeeSpring getEmployee(Integer employeeid) {
		Session session=this.sessionFactory.getCurrentSession();
		EmployeeSpring es=session.load(EmployeeSpring.class,employeeid);
		return es;
	}

	@Override
	@Transactional
	public EmployeeSpring updateEmployee(EmployeeSpring employee) {
		Session session=this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(employee);
		return employee;
	}

	
}
