
package com.neo.service;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.neo.model.Employee;
import com.neo.util.DbConnection;

public class EmployeeServiceImpl implements EmployeeService {

	Connection con =null;
	PreparedStatement ps=null;
	@Override
	public void saveEmployee(Employee emp) {
	try {
		con = DbConnection.getDbConnection();
		String sql="INSERT INTO employee(firstName,lastName,salary,age,email)"+"VALUES(?,?,?,?,?)";
		ps= (PreparedStatement) con.prepareStatement(sql);
		ps.setString(1, emp.getFirstName());
		ps.setString(2, emp.getLastName());
		ps.setDouble(3, emp.getSalary());
		ps.setInt(4, emp.getAge());
		ps.setString(5, emp.getEmail());
		
		int i= ps.executeUpdate();
		System.out.println("Saved");
		
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
		
	}

	@Override
	public List<Employee> allEmployees() {
	List<Employee> empList=new ArrayList<Employee>();
	try {
		con=DbConnection.getDbConnection();
		String sql="SELECT * FROM employee";
		ps=(PreparedStatement) con.prepareStatement(sql);
		ResultSet rs= (ResultSet) ps.executeQuery();
		while(rs.next()) {
			Employee e= new Employee();
			e.setId(rs.getInt("id"));
			e.setFirstName(rs.getString("firstName"));
			e.setLastName(rs.getString("lastName"));
			e.setSalary(rs.getDouble("salary"));
			e.setAge(rs.getInt("age"));
			e.setEmail(rs.getString("email"));
			empList.add(e);
		}
	}catch(ClassNotFoundException e) {
		e.printStackTrace();
	}catch(SQLException e) {
		e.printStackTrace();
	}
	System.out.println("size..."+empList.size());
		return empList;
	}

	@Override
	public void deleteEmployee(Integer id) {
		try {
			con=DbConnection.getDbConnection();
			String sql="DELETE FROM employee WHERE id=?";
			ps=(PreparedStatement) con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
			System.out.println("Data Deleted successsfully of id :: "+id);
			
		}catch(ClassNotFoundException e) {
			e.getMessage();
		}catch(SQLException e) {
			e.getMessage();
		}finally {
			try {
				ps.close();
				con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public Employee employeeById(Integer id) {
		Employee e=null;
		try {
			con=DbConnection.getDbConnection();
			String sql="SELECT * FROM employee WHERE id=?";
			ps=(PreparedStatement) con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=(ResultSet) ps.executeQuery();
			while(rs.next()) {
				e= new Employee();
				e.setId(rs.getInt("id"));
				e.setFirstName(rs.getString("firstName"));
				e.setLastName(rs.getString("lastName"));
				e.setSalary(rs.getDouble("salary"));
				e.setAge(rs.getInt("age"));
				e.setEmail(rs.getString("email"));
			}
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return e;
	}

	@Override
	public void updateEmployee(Employee emp) {
		try {
			con=DbConnection.getDbConnection();
			String sql="UPDATE employee SET firstName=?,lastName=?,salary=?,age=?,email=? WHERE id=?";
			ps=(PreparedStatement) con.prepareStatement(sql);
			ps.setString(1, emp.getFirstName());
			ps.setString(2, emp.getLastName());
			ps.setDouble(3, emp.getSalary());
			ps.setInt(4, emp.getAge());
			ps.setString(5, emp.getEmail());
			ps.setInt(6, emp.getId());
			
			Integer id=ps.executeUpdate();
			System.out.println("Updateid...."+emp.getId());
			
		}catch(Exception ex) {
			System.out.println("Exception from catch block....");
		}
		
	}

	@Override
	public List<Employee> empByFirstName(String firstName) {
		List<Employee> empList=new ArrayList<Employee>();
		Employee e=null;
		try {
			con=DbConnection.getDbConnection();
			String sql="SELECT * FROM employee WHERE firstName=?";
			ps=(PreparedStatement) con.prepareStatement(sql);
			ps.setString(1, firstName);
			ResultSet rs=(ResultSet) ps.executeQuery();
			while(rs.next()) {
				e= new Employee();
				e.setId(rs.getInt("id"));
				e.setFirstName(rs.getString("firstName"));
				e.setLastName(rs.getString("lastName"));
				e.setSalary(rs.getDouble("salary"));
				e.setAge(rs.getInt("age"));
				e.setEmail(rs.getString("email"));
				empList.add(e);
			}
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		System.out.println("...empListSearch..."+empList.size());
		return empList;
	}

}
