package sam;

import java.util.ArrayList;

public class Anytype {
	public static void main(String[] args) {
		ArrayList ts=new ArrayList();
		ts.add("Sanjay");
		ts.add("Sam");
		ts.add(27656734);
		ts.add(7634.0834);
	//System.out.println(ts);
		for(int i=0;i<ts.size();i++) {
			//System.out.println(ts);
		}
	}
}
