package sam;

public class Thread2 {

}
