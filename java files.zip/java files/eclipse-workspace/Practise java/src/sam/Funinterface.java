package sam;

public interface Funinterface {
public int Sum(int a,int b);
}
