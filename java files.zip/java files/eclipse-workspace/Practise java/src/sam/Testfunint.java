package sam;

public class Testfunint {
public static void main(String[] args) {
	Funinterface res=(a,b)-> a+b;
	System.out.println("Sum is: "+res.Sum(10, 20));
}
}
