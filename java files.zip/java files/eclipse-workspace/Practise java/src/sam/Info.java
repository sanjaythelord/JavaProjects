package sam;

public class Info {

}
