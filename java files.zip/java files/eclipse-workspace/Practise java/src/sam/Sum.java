package sam;

public class Sum {
int num,val;
Sum(int num,int val){
this.num=num;
this.val=val;
}
public int getNum() {
	return num;
}
public void setNum(int num) {
	this.num = num;
}
public int getVal() {
	return val;
}
public void setVal(int val) {
	this.val = val;
}

}
