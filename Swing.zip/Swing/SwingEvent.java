package Swing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class SwingEvent extends JFrame implements ActionListener
{
    private int count =0;
    JLabel lblData;
    SwingEvent()
    {
        setLayout(new FlowLayout());
        lblData = new JLabel("Button Clicked 0 Times");
        JButton btnClick=new JButton("Click Me");
        btnClick.addActionListener(this);
        add(lblData);
        add(btnClick);
    }
    public void actionPerformed(ActionEvent e)
    {
        count++;
        lblData.setText("Button Clicked " + count +" Times");
    }
}
class EventHandlingJavaExample
{
    public static void main(String args[])
    {
        SwingEvent frame = new SwingEvent();
        frame.setTitle("Event Handling Java Example");
        frame.setBounds(200,150,180,150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}